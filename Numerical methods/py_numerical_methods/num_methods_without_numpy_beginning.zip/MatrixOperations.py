from copy import deepcopy
from MatrixClass import Matrix


def transposition(matrix):
    transpose_matrix = []
    for i in range(len(matrix)):
        transpose_matrix.append([])
        for j in range(len(matrix[0])):
            transpose_matrix[i].append(matrix[j][i])
    return Matrix(transpose_matrix, None)


def matrix_op(a, b, op):
    try:
        if op == '*' and type(b) not in (float, int):
            n = len(a[0])
            if n == len(b):
                c = []
                for i in range(n):
                    c.append([])
                    for j in range(n):
                        res = 0
                        for k in range(len(a)):
                            res += a[i][k] * b[k][j]
                        c[i].append(res)
                return Matrix(c, None)
            else:
                print('Index Error (matrix multiplication)')
        elif op == '*':
            return Matrix([[a[i][j] * b for j in range(len(a[0]))] for i in range(len(a))], None)
        elif op == '+':
            if len(a) == len(b) and len(a[0]) == len(b[0]):
                return Matrix([[a[i][j] + b[i][j] for j in range(len(a[0]))] for i in range(len(a))], None)
            else:
                print('Index Error (matrix summation)')
        elif op == '-':
            if len(a) == len(b) and len(a[0]) == len(b[0]):
                return Matrix([[a[i][j] - b[i][j] for j in range(len(a[0]))] for i in range(len(a))], None)
            else:
                print('Index Error (matrix subtraction)')
    except Exception as err:
        print(str(err))


def inv_matrix(main_matrix, eps):
    matrix, n, m = deepcopy(main_matrix), len(main_matrix), len(main_matrix[0])  # copy matrix
    while True:
        for i in range(min(n, m)):
            is_zero_col = False
            if abs(matrix[i][i]) < eps:  # if matrix[i][i] < eps, change rows
                for z in range(i + 1, m):
                    if not matrix[z][i] < eps:
                        matrix = Matrix.row_change(matrix, i, z)
                        break
                    if z == m - 1:
                        is_zero_col = True
                if is_zero_col:
                    continue
            else:  # else divide the current row of the matrix by matrix[i][i]
                matrix[i] = [0.0 if p < i else matrix[i][p] / matrix[i][i] for p in range(m)]

            for j in range(i + 1, n):
                div = matrix[j][i]  # save divisor for each row
                for k in range(i, m):
                    matrix[j][k] -= div * matrix[i][k]
