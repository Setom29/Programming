from MatrixClass import Matrix
# import MatrixOperations
from copy import deepcopy


def is_valid(matrix):
    """
    Check if the rank of the matrix is equal to it's dimension
    """
    rg = Matrix.rg(matrix.matrix, matrix.eps)
    if rg == len(A.matrix) and len(A.matrix[0]) == len(A.matrix):
        return True
    return False


def gauss(matrix):
    """
    Returns list of solutions to the given system of linear equations using the Gauss method,
    if  is_valid(matrix) returns True.
    """
    if not is_valid(matrix):
        return
    matrix, b, eps, eps_ind, n = deepcopy(matrix.matrix), matrix.B[:], matrix.eps, matrix.eps_ind, len(matrix.matrix)
    for i in range(n):
        is_zero_col = False
        if abs(matrix[i][i]) < eps:  # if matrix[i][i] < eps, change rows
            for z in range(i + 1, n):
                if not matrix[z][i] < eps:
                    matrix = Matrix.row_change(matrix, i, z)
                    b[i], b[z] = b[z], b[i]
                    break
                if z == n - 1:
                    is_zero_col = True
            if is_zero_col:
                continue
        else:  # else divide the current row of the matrix by matrix[i][i]
            temp = matrix[i][i]
            matrix[i] = [0.0 if p < i else round(matrix[i][p] / temp, eps_ind) for p in range(n)]
            b[i] = round(b[i] / temp, eps_ind)
        for j in range(i + 1, n):
            div = matrix[j][i]  # save divisor for each row
            for k in range(i, n):
                matrix[j][k] -= div * matrix[i][k]
            b[j] -= div * b[i]
        # reverse
    x = [0.0] * n
    x[n - 1] = b[n - 1] / matrix[n - 1][n - 1]
    for i in range(n - 1, -1, -1):
        temp = 0
        for j in range(n - 1, i, -1):
            temp += x[j] * matrix[i][j]
        x[i] = (b[i] - temp) / matrix[i][i]
    return [round(el, eps_ind) for el in x]


def gauss_with_selection(matrix):
    """
    Returns list of solutions to the given system of linear equations using the Gauss method
    with the selection of the main element, if  is_valid(matrix) returns True.
    """
    if not is_valid(matrix):
        return
    matrix, b, eps, eps_ind, n = deepcopy(matrix.matrix), matrix.B[:], matrix.eps, matrix.eps_ind, len(matrix.matrix)
    for i in range(n):
        is_zero_col = False
        max_el = i
        is_zero_col = 0
        for z in range(i, n):
            is_zero_col += 1
        if is_zero_col == 0:
            continue
        else:  # else divide the current row of the matrix by matrix[i][i]
            for z in range(i + 1, n):
                if abs(matrix[z][i]) > abs(matrix[max_el][i]):
                    max_el = z
            matrix = Matrix.row_change(matrix, i, max_el)
            b[i], b[max_el] = b[max_el], b[i]
            temp = matrix[i][i]
            matrix[i] = [0.0 if p < i else round(matrix[i][p] / temp, eps_ind) for p in range(n)]
            b[i] = round(b[i] / temp, eps_ind)
        for j in range(i + 1, n):
            div = matrix[j][i]  # save divisor for each row
            for k in range(i, n):
                matrix[j][k] -= div * matrix[i][k]
            b[j] -= div * b[i]
        # reverse
    x = [0.0] * n
    x[n - 1] = b[n - 1] / matrix[n - 1][n - 1]
    for i in range(n - 1, -1, -1):
        temp = 0
        for j in range(n - 1, i, -1):
            temp += x[j] * matrix[i][j]
        x[i] = (b[i] - temp) / matrix[i][i]
    return [round(el, eps_ind) for el in x]


A = Matrix()

g_ans = gauss(A)
if g_ans is None:
    print('Indefinite system of linear equations')
else:
    print(g_ans)

g_ans = gauss_with_selection(A)
if g_ans is None:
    print('Indefinite system of linear equations')
else:
    print(g_ans)

